# REAL DRIVE 3D (Three.js + Capacitor)
STATUS: written without internet or a browser. Syntax-checked only (node --check). NOT run, NOT tested on any device. No APK has been built.

## Run in a browser
1. `npm install && npm run vendor`  (copies three r128, loaders, Draco decoder into www/vendor)
2. `npm run assets`  (downloads three.js example Ferrari + stand-in character; URLs unverified; check licenses)
3. Add audio (see ASSETS.md), then `npm run serve` and open it on your phone (same Wi-Fi) or desktop. iPhone: Share > Add to Home Screen for fullscreen.
Publish: upload the `www` folder to any static host (Netlify, GitHub Pages, Cloudflare Pages).

## Android APK
Commit `www/assets` (models+audio you are licensed to use) and push to GitHub, then Actions > "Android debug APK" > Run. Download `app-debug.apk` from the run's artifacts. Locally: `npm run android:add`, `npm run android:sync`, open `android/` in Android Studio. Release signing and immersive fullscreen are not configured.
