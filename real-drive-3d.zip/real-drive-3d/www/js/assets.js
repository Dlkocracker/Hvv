/* Asset manifest + loaders. Cars/pedestrians must be real GLB files in www/assets/models. No primitive fallbacks. */
const ASSETS={
 // Car nodes expected: body, glass, wheel_fl, wheel_fr, wheel_rl, wheel_rr (three.js ferrari.glb uses these names).
 // yaw: set to 3.14159 if the car drives backwards. cp: cockpit camera [x,y,z] in metres.
 CARS:[
  {n:'Ferrari 458',file:'models/ferrari.glb',c:0xd91e2b,P:11,top:68,g:9,sl:.3,yaw:0,cp:[.4,1.1,.1]},
  {n:'Car 2',file:'models/car2.glb',c:0xf59e0b,P:9.5,top:62,g:7,sl:.62,yaw:0,cp:[.4,1.1,.1]},
  {n:'Car 3',file:'models/car3.glb',c:0x2a6bff,P:14,top:80,g:8.2,sl:.4,yaw:0,cp:[.4,1.1,.1]}],
 PED:'models/ped.glb',
 AUDIO:['engine_idle','engine_low','engine_mid','engine_high','tire_screech','drift_loop','brake','road_noise','music','crash','shift','horn','indicator'],
 ok:[],carSrc:[],ped:null,missing:[],
 async load(){
  const dl=new THREE.DRACOLoader();dl.setDecoderPath('vendor/draco/');const ld=new THREE.GLTFLoader();ld.setDRACOLoader(dl);
  const get=f=>new Promise((res,rej)=>ld.load('assets/'+f,res,undefined,rej));
  for(const [i,d] of this.CARS.entries()){try{this.carSrc[i]=this.norm(await get(d.file),d);this.ok[i]=true}catch(e){this.ok[i]=false;this.missing.push(d.file)}}
  try{this.ped=await get(this.PED)}catch(e){this.missing.push(this.PED)}
  for(const n of this.AUDIO){let f=false;for(const x of['mp3','ogg']){try{if((await fetch(`assets/audio/${n}.${x}`,{method:'HEAD'})).ok){f=true;break}}catch(e){}}if(!f)this.missing.push(`audio/${n}.mp3|ogg`)}
  if(!this.ok.some(Boolean)){const e=document.getElementById('fatal');e.hidden=false;e.innerHTML='<h2>No car model found</h2><div style="max-width:560px;text-align:center">Add at least one real car GLB at <b>www/assets/models/ferrari.glb</b> (run <b>npm run assets</b>) and reload.<br><br>Missing: '+this.missing.join(', ')+'</div>';return false}
  return true},
 norm(gltf,d){const w=new THREE.Group(),inner=gltf.scene;w.add(inner);inner.rotation.y=d.yaw||0;w.updateMatrixWorld(true);
  const b=new THREE.Box3().setFromObject(w),s=b.getSize(new THREE.Vector3());if(s.x>s.z){inner.rotation.y+=Math.PI/2;w.updateMatrixWorld(true);b.setFromObject(w);b.getSize(s)}
  const k=4.4/s.z;w.scale.setScalar(k);w.updateMatrixWorld(true);b.setFromObject(w);const c=b.getCenter(new THREE.Vector3());w.position.set(-c.x,-b.min.y,-c.z);
  w.userData={L:4.4,W:s.x*k,H:s.y*k};return w}};
