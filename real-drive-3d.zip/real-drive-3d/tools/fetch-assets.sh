#!/bin/bash
# Downloads the three.js example car + character. URLs are UNVERIFIED (written without network access). Read each license before shipping.
set -e; cd "$(dirname "$0")/../www/assets/models"
B=https://raw.githubusercontent.com/mrdoob/three.js/r128/examples/models/gltf
curl -fL $B/ferrari.glb -o ferrari.glb
curl -fL $B/Soldier.glb -o ped.glb   # stand-in character (Mixamo). Replace with civilian models for release.
echo done
