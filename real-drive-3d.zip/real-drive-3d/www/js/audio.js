/* Sample-based audio. Plays ONLY recorded files from www/assets/audio (mp3 or ogg). Nothing is synthesized; missing files stay silent. */
const AUDIO=(()=>{let ctx,mst,B={},L={},on=0,sfx=.7,hornS=null;const cl=(v,a,b)=>Math.max(a,Math.min(b,v));
 const REF={engine_idle:900,engine_low:2500,engine_mid:4500,engine_high:6500},LOOPS=['engine_idle','engine_low','engine_mid','engine_high','tire_screech','drift_loop','brake','road_noise','music'];
 async function buf(n){for(const e of['mp3','ogg']){try{const r=await fetch(`assets/audio/${n}.${e}`);if(r.ok)return await ctx.decodeAudioData(await r.arrayBuffer())}catch(x){}}return null}
 async function init(){if(ctx)return;ctx=new(window.AudioContext||window.webkitAudioContext)();mst=ctx.createGain();mst.connect(ctx.destination);ctx.resume&&ctx.resume();
  await Promise.all(ASSETS.AUDIO.map(async n=>B[n]=await buf(n)));
  LOOPS.forEach(n=>{if(!B[n])return;const s=ctx.createBufferSource(),g=ctx.createGain();s.buffer=B[n];s.loop=true;g.gain.value=0;s.connect(g);g.connect(mst);s.start();L[n]={s,g}});on=1}
 const set=(n,v,r)=>{const l=L[n];if(!l)return;const t=ctx.currentTime;l.g.gain.setTargetAtTime(v,t,.06);if(r)l.s.playbackRate.setTargetAtTime(r,t,.06)};
 function update(s){if(!on)return;sfx=s.sfx;const w=(c,d)=>Math.max(0,1-Math.abs(s.rpm-c)/d),ws={engine_idle:w(900,1400),engine_low:w(2500,2200),engine_mid:w(4500,2400),engine_high:w(6500,2600)},sum=Object.values(ws).reduce((a,b)=>a+b,0)||1,v=s.eng*s.sfx*(.55+.45*s.thr);
  for(const n in ws)set(n,v*ws[n]/sum,cl(s.rpm/REF[n],.6,1.7));
  set('tire_screech',s.slip*s.sfx*.7);set('drift_loop',s.slip>.5?s.slip*s.sfx*.6:0);set('brake',s.brk>.4&&s.sp>5?s.brk*s.sfx*.6:0);set('road_noise',cl(s.sp/40,0,1)*s.sfx*(s.wet?1:.6));set('music',s.mus*.6)}
 function play(n,vol){if(!on||!B[n])return;const s=ctx.createBufferSource(),g=ctx.createGain();s.buffer=B[n];g.gain.value=(vol||1)*sfx;s.connect(g);g.connect(mst);s.start()}
 function horn(d){if(!on||!B.horn)return;if(d&&!hornS){hornS=ctx.createBufferSource();const g=ctx.createGain();hornS.buffer=B.horn;hornS.loop=true;g.gain.value=sfx;hornS.connect(g);g.connect(mst);hornS.start()}else if(!d&&hornS){hornS.stop();hornS=null}}
 return{init,update,play,horn}})();
