#!/bin/bash
M=android/app/src/main/AndroidManifest.xml
grep -q sensorLandscape $M || sed -i '0,/<activity/s//<activity android:screenOrientation="sensorLandscape"/' $M
