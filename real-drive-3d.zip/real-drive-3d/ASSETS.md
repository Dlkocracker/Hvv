# Required assets (none are bundled)
Models in www/assets/models: ferrari.glb (car 1), car2.glb, car3.glb (optional), ped.glb (animated, clips named Walk/Idle).
Car node names: body, glass, wheel_fl, wheel_fr, wheel_rl, wheel_rr. Without them paint/wheel animation will not work. Edit `yaw` and `cp` in js/assets.js if a car faces backwards or the cockpit camera is misplaced.
Audio in www/assets/audio (.mp3 or .ogg, seamless loops unless noted): engine_idle (~900 rpm), engine_low (~2500), engine_mid (~4500), engine_high (~6500), tire_screech, drift_loop, brake, road_noise, music; one-shots: crash, shift, horn (loop while held), indicator (single click).
Sources to look at: Freesound.org, Sketchfab, Mixamo, paid sound libraries. Record each asset's license in LICENSES.md. three.js example models: read the README beside them in the three.js repo (I believe the Ferrari is CC-BY, Soldier is from Mixamo: verify).
