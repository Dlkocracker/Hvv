// Copies pinned three.js r128 browser files into www/vendor (run after npm install). Needed for offline Capacitor builds.
const fs=require('fs'),p=require('path'),T=p.join('node_modules','three'),V=p.join('www','vendor');
fs.mkdirSync(p.join(V,'draco'),{recursive:true});
[['build/three.min.js','three.min.js'],['examples/js/loaders/GLTFLoader.js','GLTFLoader.js'],['examples/js/loaders/DRACOLoader.js','DRACOLoader.js'],['examples/js/utils/SkeletonUtils.js','SkeletonUtils.js']].forEach(([a,b])=>fs.copyFileSync(p.join(T,a),p.join(V,b)));
const d=p.join(T,'examples/js/libs/draco/gltf');fs.readdirSync(d).forEach(f=>fs.copyFileSync(p.join(d,f),p.join(V,'draco',f)));
console.log('vendor ready');
