(async()=>{
if(!await ASSETS.load())return;
const $=id=>document.getElementById(id),V2=THREE.Vector2,V3=THREE.Vector3,cl=(v,a,b)=>Math.max(a,Math.min(b,v)),rnd=(a,b)=>a+Math.random()*(b-a),pick=a=>a[Math.random()*a.length|0],PI=Math.PI;
let S={gfx:1,eng:.8,res:2,sfx:.7,mus:.5,steer:1,ws:1,cs:1,tilt:0,arr:0,swap:0,lang:0,car:0,best:{}};
try{Object.assign(S,JSON.parse(localStorage.getItem('rd_save')||'{}'))}catch(e){}
const save=()=>{try{localStorage.setItem('rd_save',JSON.stringify(S))}catch(e){}};
const G={on:0,paused:1,mode:'',lt:0,tod:17.5,wx:0,clock:0,t:0,sc:0,cd:0},LA=['en','es'];
const LG={en:{free:'Free Drive',drift:'Drift Mode',traffic:'Traffic Mode',park:'Parking',trial:'Time Trial',school:'Driving School',settings:'Settings',back:'Back',resume:'Resume',menu:'Main menu',gfx:'Graphics',sfx:'Sound volume',eng:'Engine volume',res:'Resolution',mus:'Music volume',steer:'Steering sensitivity',ws:'Wheel size',cs:'Camera sensitivity',tilt:'Tilt steering',arr:'Arrow controls',swap:'Swap control sides',lang:'Language',wx:'Weather',tod:'Time of day',full:'Fullscreen',low:'Low',med:'Medium',high:'High',retry:'Retry',paused:'Paused',best:'Best'},
es:{free:'Conducción libre',drift:'Modo derrape',traffic:'Modo tráfico',park:'Aparcar',trial:'Contrarreloj',school:'Autoescuela',settings:'Ajustes',back:'Volver',resume:'Continuar',menu:'Menú principal',gfx:'Gráficos',sfx:'Volumen sonido',eng:'Volumen motor',res:'Resolución',mus:'Volumen música',steer:'Sensibilidad dirección',ws:'Tamaño volante',cs:'Sensibilidad cámara',tilt:'Dirección inclinando',arr:'Controles flecha',swap:'Invertir lados',lang:'Idioma',wx:'Clima',tod:'Hora del día',full:'Pantalla completa',low:'Bajo',med:'Medio',high:'Alto',retry:'Repetir',paused:'Pausa',best:'Mejor'}};
const T=k=>(LG[LA[S.lang]][k])||LG.en[k]||k;
// ---------- renderer / scene
const R=new THREE.WebGLRenderer({antialias:true,powerPreference:'high-performance'});document.body.prepend(R.domElement);
const sc=new THREE.Scene(),cam=new THREE.PerspectiveCamera(65,1,.1,800);sc.fog=new THREE.FogExp2(0x8cc4ff,.0016);sc.background=new THREE.Color(0x8cc4ff);
const hemi=new THREE.HemisphereLight(0xbfd8ff,0x444433,.7),sun=new THREE.DirectionalLight(0xffffff,1);sc.add(hemi,sun,sun.target);
Object.assign(sun.shadow.camera,{left:-45,right:45,top:45,bottom:-45,near:1,far:320});sun.shadow.bias=-.0005;
const M=(c,r=.7,m=0,o)=>new THREE.MeshStandardMaterial(Object.assign({color:c,roughness:r,metalness:m},o));
const cv=(w,h,f)=>{const c=document.createElement('canvas');c.width=w;c.height=h;f(c.getContext('2d'),w,h);const t=new THREE.CanvasTexture(c);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.anisotropy=4;return t};
const cubeRT=new THREE.WebGLCubeRenderTarget(64),cubeCam=new THREE.CubeCamera(.5,500,cubeRT),envT=cubeRT.texture;
function applyGfx(){R.setPixelRatio([1,Math.min(devicePixelRatio,1.5),Math.min(devicePixelRatio,2)][S.gfx]*[.5,.75,1][S.res]);R.setSize(innerWidth,innerHeight);R.shadowMap.enabled=S.gfx>0;R.shadowMap.type=THREE.PCFSoftShadowMap;sun.castShadow=S.gfx>0;const s=S.gfx>1?2048:1024;if(sun.shadow.mapSize.x!==s){sun.shadow.mapSize.set(s,s);if(sun.shadow.map){sun.shadow.map.dispose();sun.shadow.map=null}}}
addEventListener('resize',()=>{cam.aspect=innerWidth/innerHeight;cam.updateProjectionMatrix();R.setSize(innerWidth,innerHeight)});
// ---------- city
const rd=c=>{const d=((c%50)+50)%50;return d>25?50-d:d};
const BL={},NB=[],LOTS=[],GAS=[];
const pat=[...Array(128)].map(()=>Math.random()<.4);
const wt=cv(128,256,(g,w,h)=>{g.fillStyle='#69707c';g.fillRect(0,0,w,h);for(let i=0;i<128;i++){g.fillStyle=pat[i]?'#cfd9e6':'#1b2430';g.fillRect((i%8)*16+3,(i/8|0)*16+3,10,10)}}),
et=cv(128,256,(g,w,h)=>{g.fillStyle='#000';g.fillRect(0,0,w,h);for(let i=0;i<128;i++)if(pat[i]){g.fillStyle='#ffd9a0';g.fillRect((i%8)*16+3,(i/8|0)*16+3,10,10)}});
const BM=[0xffffff,0xe0d2bd,0xb8c6d8].map(c=>{const m=M(c,.5,.2,{map:wt,emissiveMap:et,emissive:0xffffff,emissiveIntensity:0});NB.push(m);return m});
const rt=cv(128,128,(g,w,h)=>{g.fillStyle='#2b2d31';g.fillRect(0,0,w,h);for(let i=0;i<900;i++){g.fillStyle=`rgba(${Math.random()*90|0},${Math.random()*90|0},${Math.random()*90|0},.25)`;g.fillRect(Math.random()*w,Math.random()*h,2,2)}g.fillStyle='#e8e8e8';g.fillRect(0,3,w,3);g.fillRect(0,h-6,w,3);g.fillStyle='#f2c200';for(let x=0;x<w;x+=64)g.fillRect(x,h/2-2,32,4)});rt.repeat.set(52,1);
const roadM=M(0xffffff,.9,0,{map:rt}),plainM=M(0x2b2d31,.9),stM=M(0x9b9b9b,.9),lotT=cv(128,128,(g,w,h)=>{g.fillStyle='#34363a';g.fillRect(0,0,w,h);g.fillStyle='#ddd';for(let i=0;i<=8;i++)g.fillRect(i*16-1,0,2,28),g.fillRect(i*16-1,h-28,2,28)});
const gnd=new THREE.Mesh(new THREE.PlaneGeometry(2400,2400).rotateX(-PI/2),M(0x3b4a38,1));gnd.receiveShadow=true;sc.add(gnd);
const add=(m,x,y,z)=>{m.position.set(x,y,z);m.castShadow=m.receiveShadow=true;sc.add(m);return m};
const BX=new THREE.BoxGeometry(1,1,1);
const bxm=(mat,w,h,d,x,y,z)=>{const m=new THREE.Mesh(BX,mat);m.scale.set(w,h,d);return add(m,x,y,z)};
for(let k=-4;k<=4;k++){const a=new THREE.Mesh(new THREE.PlaneGeometry(420,14).rotateX(-PI/2),roadM);a.position.set(0,.02,k*50);a.receiveShadow=true;sc.add(a);const b=a.clone();b.rotation.y=PI/2;b.position.set(k*50,.02,0);b.position.y=.025;sc.add(b)}
for(let i=-4;i<=4;i++)for(let j=-4;j<=4;j++){const q=new THREE.Mesh(new THREE.PlaneGeometry(14,14).rotateX(-PI/2),plainM);q.position.set(i*50,.04,j*50);q.receiveShadow=true;sc.add(q)}
const forced={'1,1':'g','-3,-2':'g','-2,2':'g','0,1':'p','2,-2':'p','-1,-3':'p','2,2':'d','-3,1':'d'};
for(let i=-4;i<4;i++)for(let j=-4;j<4;j++){const x=i*50+25,z=j*50+25,r=Math.random(),t=forced[i+','+j]||(r<.82?'b':r<.9?'p':r<.96?'g':'d'),B=BL[i+','+j]={t,x,z};
 bxm(stM,36,.3,36,x,.15,z);
 if(t==='b'){const h=(Math.abs(i+.5)<2&&Math.abs(j+.5)<2?rnd(60,130):rnd(14,60));const g=new THREE.BoxGeometry(24,h,24),u=g.attributes.uv;for(let n=0;n<u.count;n++)u.setXY(n,u.getX(n)*1.7,u.getY(n)*h/14);add(new THREE.Mesh(g,pick(BM)),x,h/2+.3,z)}
 else if(t==='p'){LOTS.push(B);const f=new THREE.Mesh(new THREE.PlaneGeometry(30,30).rotateX(-PI/2),M(0xffffff,.9,0,{map:lotT}));f.position.set(x,.32,z);f.receiveShadow=true;sc.add(f)}
 else if(t==='g'){GAS.push(B);bxm(M(0xe9e9ef,.5),22,.5,11,x,5.3,z);[-1,1].forEach(s=>[-1,1].forEach(q=>bxm(M(0x444),.4,5,.4,x+s*10,2.8,z+q*4.5)));[-5,0,5].forEach(s=>bxm(M(0xd02020,.5),.9,1.3,.6,x+s,1,z));bxm(M(0xcfd6dd,.6),16,4,5,x,2.3,z+13);bxm(new THREE.MeshBasicMaterial({color:0x18e0d0}),6,1,.3,x,5.9,z+10.4)}
 else{bxm(M(0x7fb4d6,.05,.9,{transparent:true,opacity:.7}),24,8,24,x,4.3,z);bxm(new THREE.MeshBasicMaterial({color:0xffb000}),8,1.5,.5,x,9.2,z-12)}}
const solid=(x,z)=>{if(rd(x)<13.5||rd(z)<13.5)return 0;const b=BL[Math.floor(x/50)+','+Math.floor(z/50)];return b&&(b.t==='b'||b.t==='d')?b:0};
// traffic lights, streetlights, crosswalks (instanced)
const IM=(g,m,n)=>{const i=new THREE.InstancedMesh(g,m,n);i.frustumCulled=false;sc.add(i);return i},dm=new THREE.Object3D();
const put=(im,i,x,y,z,ry)=>{dm.position.set(x,y,z);dm.rotation.y=ry||0;dm.updateMatrix();im.setMatrixAt(i,dm.matrix)};
const LM=[0,1].map(()=>({r:new THREE.MeshBasicMaterial(),y:new THREE.MeshBasicMaterial(),g:new THREE.MeshBasicMaterial()})),bulbM=new THREE.MeshBasicMaterial({color:0xffe2a0});
const poles=IM(new THREE.CylinderGeometry(.12,.12,6.6,6),M(0x333840),324),bulbs=IM(new THREE.BoxGeometry(.5,.2,.5),bulbM,324),zeb=IM(new THREE.PlaneGeometry(2.6,.5).rotateX(-PI/2),new THREE.MeshBasicMaterial({color:0xdddddd}),2592);
const lg=[new THREE.BoxGeometry(.14,.3,.3),new THREE.BoxGeometry(.3,.3,.14)],lim=[0,1].map(a=>['r','y','g'].map(c=>IM(lg[a],LM[a][c],324)));
let ni=0,nz=0;for(let a=-4;a<=4;a++)for(let b=-4;b<=4;b++){[-1,1].forEach(cx=>[-1,1].forEach(cz=>{const px=a*50+cx*8.5,pz=b*50+cz*8.5;put(poles,ni,px,3.3,pz);put(bulbs,ni,px,6.7,pz);
 [6,5.6,5.2].forEach((y,n)=>{put(lim[0][n],ni,px+cx*.2,y,pz);put(lim[1][n],ni,px,y,pz+cz*.2)});ni++}));
 for(let n=0;n<8;n++){const o=-5.25+n*1.5;[-1,1].forEach(s=>{put(zeb,nz++,a*50+s*10,.06,b*50+o);put(zeb,nz++,a*50+o,.06,b*50+s*10,PI/2)})}}
const CYC=22,ls=ax=>{const t=(G.lt+(ax?11:0))%CYC;return t<8?'g':t<9.5?'y':'r'},lrem=ax=>CYC-((G.lt+(ax?11:0))%CYC);
// ---------- cars
const G0={b:new THREE.BoxGeometry(1.9,.5,4.5),c:new THREE.BoxGeometry(1.55,.46,2.1),w:new THREE.CylinderGeometry(.34,.34,.26,14).rotateZ(PI/2),r:new THREE.CylinderGeometry(.2,.2,.28,8).rotateZ(PI/2)};
const tireM=M(0x111111,.9),rimM=M(0xbbbbbb,.3,.9),glA=M(0x1b2733,.1,.5,{transparent:true,opacity:.6}),hdA=new THREE.MeshBasicMaterial({color:0x555544}),tlA=new THREE.MeshBasicMaterial({color:0x440000});
const CARS=ASSETS.CARS;
const bxc=(par,mat,w,h,d,x,y,z)=>{const m=new THREE.Mesh(BX,mat);m.scale.set(w,h,d);m.position.set(x,y,z);par.add(m);return m};
function makeCar(col,full,df){
 const idx=df?CARS.indexOf(df):ASSETS.ok.indexOf(true),src=ASSETS.carSrc[idx],g=new THREE.Group(),b=new THREE.Group(),u=g.userData,m=src.clone(true);g.add(b);b.add(m);u.b=b;u.L=src.userData.L;
 m.traverse(o=>{if(!o.isMesh)return;o.castShadow=full;if(/^body$/i.test(o.name)){o.material=o.material.clone();o.material.color.setHex(col);if(full){o.material.envMap=envT;o.material.envMapIntensity=1.2}}else if(full&&/glass/i.test(o.name)){o.material=o.material.clone();o.material.envMap=envT}});
 const wn=['wheel_fl','wheel_fr','wheel_rl','wheel_rr'].map(n=>m.getObjectByName(n)).filter(Boolean);wn.forEach(w=>w.rotation.order='YXZ');u.wh=wn;u.fr=wn.slice(0,2);u.dr=[];u.sw=new THREE.Object3D();
 if(full){const W=src.userData.W,L=u.L,H=src.userData.H,E=(c,e)=>new THREE.MeshStandardMaterial({color:c,emissive:e,emissiveIntensity:0}),hm=E(0xffffee,0xffffff),tm=E(0x550000,0xff0000),il=E(0x553300,0xff9500),ir=E(0x553300,0xff9500),rm=E(0x888888,0xffffff);
  const lamp=(mat,w,x,y,z)=>{const q=new THREE.Mesh(BX,mat);q.scale.set(w,.09,.05);q.position.set(x,y,z);b.add(q)};
  [-1,1].forEach(s=>{lamp(hm,.34,s*W*.32,H*.38,L/2-.03);lamp(tm,.4,s*W*.34,H*.42,-L/2+.03);lamp(s>0?il:ir,.18,s*W*.42,H*.36,L/2-.03);lamp(s>0?il:ir,.18,s*W*.42,H*.4,-L/2+.03);lamp(rm,.15,s*W*.18,H*.4,-L/2+.03)});
  Object.assign(u,{il,ir,tm,hm,rm});u.sp=[-1,1].map(s=>{const l=new THREE.SpotLight(0xfff0d0,0,80,.55,.5,1),t=new THREE.Object3D();l.position.set(s*W*.32,H*.4,L/2);t.position.set(s*W*.32,0,L/2+25);g.add(l,t);l.target=t;return l})}
 return g}
const P={p:new V2(-3.5,-40),h:0,v:new V2(),steer:0,gear:1,man:0,sc:0,rpm:900,fuel:1,thr:0,brk:0,hb:0,ind:0,haz:0,hl:0,cam:0,door:0,def:CARS[S.car],car:null,dist:0,fy:0,fp:.4};
function setCar(i){S.car=i;save();P.def=CARS[i];if(P.car)sc.remove(P.car);P.car=makeCar(P.def.c,true,P.def);sc.add(P.car)}
// ---------- particles
const smT=cv(64,64,g=>{const r=g.createRadialGradient(32,32,2,32,32,30);r.addColorStop(0,'rgba(255,255,255,.9)');r.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=r;g.fillRect(0,0,64,64)});
const SM=[...Array(70)].map(()=>{const s=new THREE.Sprite(new THREE.SpriteMaterial({map:smT,transparent:true,opacity:0,depthWrite:false,color:0xdddddd}));s.visible=false;s.userData={l:0,m:1,vx:0,vz:0};sc.add(s);return s});let si=0;
const puff=(x,z,vx,vz)=>{const s=SM[si++%70],d=s.userData;s.position.set(x,.3,z);d.vx=vx;d.vz=vz;d.l=d.m=1.4;s.visible=true};
const MK=new THREE.InstancedMesh(new THREE.PlaneGeometry(.3,.9).rotateX(-PI/2),new THREE.MeshBasicMaterial({color:0x080808,transparent:true,opacity:.55,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-2}),900);MK.frustumCulled=false;MK.count=0;sc.add(MK);let mi=0;
const rn=new THREE.LineSegments(new THREE.BufferGeometry(),new THREE.LineBasicMaterial({color:0xaac4ff,transparent:true,opacity:.5})),rp=new Float32Array(900*6);
for(let i=0;i<900;i++){const x=rnd(-25,25),y=rnd(0,25),z=rnd(-25,25);rp.set([x,y,z,x-.1,y+.7,z],i*6)}rn.geometry.setAttribute('position',new THREE.BufferAttribute(rp,3));rn.frustumCulled=false;sc.add(rn);
// ---------- AI traffic
const rt_=d=>new V2(-d.y,d.x),AI=[],COLS=[0xeeeeee,0x222222,0x8a8f98,0x1d4e89,0x7a1f1f,0xd8b400,0x2e6b3a,0xbb5a1a];
for(let i=0;i<12;i++){const c={g:makeCar(pick(COLS),false),mode:0};sc.add(c.g);AI.push(c)}
function placeAI(c){c.ax=Math.random()<.5?0:1;c.s=Math.random()<.5?1:-1;c.L=((Math.random()*9|0)-4)*50;const u=(Math.random()*8|0)*50-175+rnd(-8,8);c.d=c.ax?new V2(0,c.s):new V2(c.s,0);c.mode=0;c.v=rnd(5,10);c.vt=rnd(11,16);c.go=0;c.stuck=0;c.ghost=0;c.h=0;c.p=(c.ax?new V2(c.L,u):new V2(u,c.L)).addScaledVector(rt_(c.d),3.5)}
const bez=(a,b,c,t)=>new V2((1-t)*(1-t)*a.x+2*(1-t)*t*b.x+t*t*c.x,(1-t)*(1-t)*a.y+2*(1-t)*t*b.y+t*t*c.y);
function updAI(c,dt){let vt=c.vt;
 if(c.mode===0){const K=15,s=c.s,u=c.ax?c.p.y:c.p.x,m=s>0?Math.ceil((u+K-.01)/50)*50:Math.floor((u-K+.01)/50)*50,ds=(m-s*K-u)*s,st=ls(c.ax);
  if(st!=='g'&&!c.go&&ds>0){if(st==='y'&&ds<c.v*c.v/12+2)c.go=1;else if(ds<45)vt=Math.min(vt,Math.sqrt(Math.max(ds-.5,0))*3)}
  if(c.ghost<=0){const chk=(x,z)=>{const rx=x-c.p.x,rz=z-c.p.y,al=rx*c.d.x+rz*c.d.y,la=Math.abs(-rx*c.d.y+rz*c.d.x);if(al>0&&al<7+c.v*.9&&la<2.4)vt=Math.min(vt,Math.max(0,al-5.5)*1.2)};chk(P.p.x,P.p.y);for(const o of AI)if(o!==c&&o.g.visible)chk(o.p.x,o.p.y)}else c.ghost-=dt;
  c.stuck=c.v<.3&&vt>.5?c.stuck+dt:0;if(c.stuck>5){c.ghost=4;c.stuck=0}
  c.v+=cl(vt-c.v,-9*dt,3.5*dt);c.p.addScaledVector(c.d,c.v*dt);c.h=Math.atan2(c.d.x,c.d.y);
  const u2=c.ax?c.p.y:c.p.x,ds2=(m-s*K-u2)*s;
  if(ds2<=.2){if(!c.go&&st!=='g'&&ds2>-3){c.v=0;return}
   const C=c.ax?new V2(c.L,m):new V2(m,c.L),ops=[];[0,1,2].forEach(o=>{const nd=o===0?c.d.clone():o===1?new V2(c.d.y,-c.d.x):new V2(-c.d.y,c.d.x);const q=C.clone().addScaledVector(nd,50);if(Math.abs(q.x)<=200&&Math.abs(q.y)<=200)ops.push([o,nd])});
   const [o,nd]=pick(ops),P2=C.clone().addScaledVector(nd,K).addScaledVector(rt_(nd),3.5),P0=c.p.clone(),Cc=o===0?P0.clone().add(P2).multiplyScalar(.5):c.d.clone().multiplyScalar(P2.dot(c.d)).addScaledVector(nd,P0.dot(nd));
   Object.assign(c,{mode:1,bz:[P0,Cc,P2],u:0,nd,o,len:P0.distanceTo(Cc)+Cc.distanceTo(P2),C,go:0})}}
 else{const o=c.o;vt=o?Math.min(vt,7):vt;c.v+=cl(vt-c.v,-9*dt,3.5*dt);c.u=Math.min(1,c.u+c.v*dt/(c.len*.95));const [a,b,e]=c.bz,t=c.u;c.p=bez(a,b,e,t);c.h=Math.atan2(2*(1-t)*(b.x-a.x)+2*t*(e.x-b.x),2*(1-t)*(b.y-a.y)+2*t*(e.y-b.y));
  if(c.u>=1){c.p=e.clone();c.d=c.nd;if(o){c.L=c.ax?c.C.y:c.C.x;c.ax=1-c.ax}c.s=c.ax?c.d.y:c.d.x;c.mode=0;c.go=0}}
 c.g.position.set(c.p.x,0,c.p.y);c.g.rotation.y=c.h;c.g.userData.wh.forEach(w=>w.rotation.x+=c.v*dt/.34)}
// ---------- pedestrians
const PED=[];
function makePed(){const clone=THREE.SkeletonUtils.clone(ASSETS.ped.scene),g=new THREE.Group(),A=ASSETS.ped.animations;g.add(clone);g.rotation.order='YXZ';clone.traverse(o=>{if(o.isMesh){o.castShadow=true;o.frustumCulled=false}});
 const mx=new THREE.AnimationMixer(clone),f=n=>A.find(a=>a.name.toLowerCase()===n),wk=f('walk')||A[0],id=f('idle')||wk;g.userData={mx,wk:mx.clipAction(wk),id:mx.clipAction(id),mv:-1};g.userData.id.play();g.scale.setScalar(rnd(.95,1.05));return g}
if(ASSETS.ped)for(let i=0;i<14;i++){const g=makePed();sc.add(g);PED.push({g,ax:Math.random()<.5?0:1,L:((Math.random()*9|0)-4)*50,side:pick([-1,1]),off:10+rnd(-1.5,1.5),u:rnd(-190,190),dir:pick([-1,1]),down:0,sp:rnd(1.3,1.7)})}
function updPed(p,dt){const g=p.g,U=g.userData;if(p.down>0){p.down-=dt;g.rotation.x=-1.5;g.position.y=.35;return}g.rotation.x=0;g.position.y=.3;
 const K=9,s=p.dir,u=p.u,m=s>0?Math.ceil((u+K-.01)/50)*50:Math.floor((u-K+.01)/50)*50,d=(m-s*K-u)*s,ca=1-p.ax,wait=d>0&&d<.4&&!(ls(ca)==='r'&&lrem(ca)>10);
 if(!wait)p.u+=s*p.sp*dt;if(Math.abs(p.u)>205)p.dir*=-1;
 const o=p.L+p.side*p.off;if(p.ax)g.position.set(o,.3,p.u);else g.position.set(p.u,.3,o);g.rotation.y=p.ax?(p.dir>0?0:PI):(p.dir>0?PI/2:-PI/2);
 const mv=!wait?1:0;if(mv!==U.mv){U.mv=mv;const a=mv?U.wk:U.id,b=mv?U.id:U.wk;a.reset().play();a.crossFadeFrom(b,.25,false)}U.mx.update(dt*(mv?p.sp/1.4:1))}
// ---------- audio (recorded samples only, see js/audio.js)
function initAudio(){AUDIO.init()}function thud(){AUDIO.play('crash')}
// ---------- input
const B={gas:0,brk:0,hb:0,l:0,r:0},KY={};let wa=0,wh=0,ks=0,tv=0;
const hold=(id,f)=>{const e=$(id),d=v=>{e.setPointerCapture&&0;f(1);e.classList.add('on')},u=()=>{f(0);e.classList.remove('on')};e.addEventListener('pointerdown',ev=>{ev.preventDefault();try{e.setPointerCapture(ev.pointerId)}catch(x){}d()});['pointerup','pointercancel','lostpointercapture'].forEach(n=>e.addEventListener(n,u))};
const tap=(id,f)=>$(id).addEventListener('pointerdown',ev=>{ev.preventDefault();f()});
hold('gas',v=>B.gas=v);hold('brk',v=>B.brk=v);hold('hb',v=>B.hb=v);hold('hn',v=>AUDIO.horn(v));hold('al',v=>B.l=v);hold('arr',v=>B.r=v);
const setInd=d=>{P.ind=P.ind===d?0:d;P.haz=0},toggles=()=>{$('bl').classList.toggle('on',P.ind===1);$('br').classList.toggle('on',P.ind===-1);$('bh').classList.toggle('on',!!P.haz);$('bhl').classList.toggle('on',!!P.hl);$('bd').classList.toggle('on',!!P.door)};
const act={ind1:()=>setInd(1),ind2:()=>setInd(-1),haz:()=>{P.haz^=1;P.ind=0},hl:()=>P.hl^=1,cam:()=>{P.cam=(P.cam+1)%6;say(['Chase','Cockpit','Free','Bumper','Hood','Cinematic'][P.cam]+' cam',900)},door:()=>say('This model has no separate door parts',1500),
 R:()=>{if(Math.abs(P.v.dot(new V2(Math.sin(P.h),Math.cos(P.h))))<4){P.gear=-1;P.man=1}else say('Slow down first',900)},D:()=>{P.gear=1;P.man=0},up:()=>{P.gear=Math.min(6,Math.max(1,P.gear+1));P.man=1},dn:()=>{P.gear=Math.max(-1,P.gear-1);P.man=1}};
[['bl','ind1'],['br','ind2'],['bh','haz'],['bhl','hl'],['bc','cam'],['bd','door'],['gR','R'],['gD','D'],['gU','up'],['gDn','dn']].forEach(([i,a])=>tap(i,()=>{act[a]();toggles()}));
tap('pause',()=>pauseMenu());
addEventListener('keydown',e=>{KY[e.code]=1;const m={KeyQ:'ind1',KeyE:'ind2',KeyZ:'haz',KeyH:'hl',KeyC:'cam',KeyO:'door',KeyR:'R',KeyT:'D',ShiftLeft:'up',ControlLeft:'dn'}[e.code];if(m&&G.on){act[m]();toggles()}if(e.code==='Escape'&&G.on)pauseMenu();if(e.code==='KeyF')fs();if(e.code==='KeyV')AUDIO.horn(1);if(e.code==='Space')e.preventDefault()});
addEventListener('keyup',e=>{KY[e.code]=0;if(e.code==='KeyV')AUDIO.horn(0)});
const W=$('wheel');let wl=0;const wang=e=>{const r=W.getBoundingClientRect();return Math.atan2(e.clientY-r.top-r.height/2,e.clientX-r.left-r.width/2)*57.3};
W.addEventListener('pointerdown',e=>{try{W.setPointerCapture(e.pointerId)}catch(x){}wh=1;wl=wang(e)});
W.addEventListener('pointermove',e=>{if(!wh)return;const a=wang(e);let d=a-wl;if(d>180)d-=360;if(d<-180)d+=360;wa=cl(wa+d,-450,450);wl=a});
['pointerup','pointercancel'].forEach(n=>W.addEventListener(n,()=>wh=0));
let drag=0;R.domElement.addEventListener('pointerdown',e=>{drag=1});addEventListener('pointerup',()=>drag=0);
R.domElement.addEventListener('pointermove',e=>{if(drag&&P.cam===2){P.fy-=e.movementX*.006*S.cs;P.fp=cl(P.fp+e.movementY*.005*S.cs,.05,1.3)}});
addEventListener('deviceorientation',e=>{if(!S.tilt||e.beta==null){tv=0;return}const a=screen.orientation?screen.orientation.angle:90;tv=cl((a===270?-e.beta:e.beta)/-32,-1,1)*(S.tilt===2?-1:1)*S.steer});
// ---------- HUD helpers
let mt2=0;const say=(t,ms)=>{const m=$('msg');m.textContent=t;m.style.opacity=1;clearTimeout(mt2);mt2=setTimeout(()=>m.style.opacity=0,ms||1600)};
const D={cur:0,mult:1,chain:0,total:0,gap:0,act:0,ang:0};
function bank(lose){if(D.cur>20){if(lose){say('DRIFT LOST',1200)}else{D.total+=Math.round(D.cur);say('+'+Math.round(D.cur),1200)}}D.cur=0;D.chain=0;D.mult=1;D.act=0;D.gap=0}
function hit(v){if(G.cd>0)return;G.cd=.8;thud();bank(1);if(G.mode==='traffic'){G.clean=0;G.sc=Math.max(0,G.sc-150)}say('CRASH!',900)}
// ---------- physics
const GT=[0,14,24,35,46,57,68];let acc=0,vlS=0;
function drive(dt){const p=P,df=p.def,wet=G.wx===1?.78:1;
 let f=new V2(Math.sin(p.h),Math.cos(p.h)),l=new V2(Math.cos(p.h),-Math.sin(p.h));let vf=p.v.dot(f),vl=p.v.dot(l);const sp=Math.abs(vf);
 const thrT=(B.gas||KY.KeyW||KY.ArrowUp)?1:0,brkT=(B.brk||KY.KeyS||KY.ArrowDown)?1:0,hbT=B.hb||KY.Space,kT=((KY.KeyA||KY.ArrowLeft||B.l)?1:0)-((KY.KeyD||KY.ArrowRight||B.r)?1:0);
 p.thr+=(thrT-p.thr)*cl(dt*7,0,1);p.brk+=(brkT-p.brk)*cl(dt*9,0,1);if(p.fuel<=0)p.thr=0;p.hb=hbT?1:0;ks+=(kT-ks)*cl(dt*(kT?4:7),0,1);
 if(!wh)wa*=Math.exp(-5*dt);
 const stIn=cl(-wa/270*S.steer+ks+tv,-1,1);p.steer+=(stIn-p.steer)*cl(dt*(wh?16:9),0,1);
 const delta=p.steer*.62/(1+sp/20);let gb=df.g*wet,grip=gb;
 if(p.hb&&sp>2)grip=1.2;else grip*=1-df.sl*p.thr*cl(Math.abs(p.steer)*sp/9,0,1);
 grip/=1+.6*(vl/5)**2;const r=cl(grip/gb,0,1);
 let yaw=vf*Math.tan(delta)/2.7;const ym=(17*wet/Math.max(sp,5))*(1+1.3*(1-r));yaw=cl(yaw,-ym,ym);if(p.hb&&sp>3)yaw*=1.25;
 p.h+=yaw*dt;f.set(Math.sin(p.h),Math.cos(p.h));l.set(Math.cos(p.h),-Math.sin(p.h));vf=p.v.dot(f);vl=p.v.dot(l)*Math.exp(-grip*dt);
 const k=df.top/68,gt=p.gear>0?GT[p.gear]*k:p.gear<0?10:1,ratio=Math.abs(vf)/gt,raw=900+Math.min(1.08,ratio)*6700;
 if(!p.man&&p.gear>0){p.sc-=dt;if(raw>7100&&p.gear<6&&p.sc<=0){p.gear++;p.sc=.4;AUDIO.play('shift')}else if(raw<2700&&p.gear>1&&p.sc<=0){p.gear--;p.sc=.4;AUDIO.play('shift')}}
 p.rpm+=((p.gear===0?900+p.thr*5500:Math.max(raw,900+p.thr*2200*(1-Math.min(1,ratio))))-p.rpm)*cl(dt*9,0,1);
 let a=0;if(p.gear>0&&vf>-2){const tq=Math.max(.15,1-.45*((p.rpm-5200)/4800)**2);a=p.thr*df.P*tq*Math.pow(14*k/gt,.8)*(ratio<1?1:0)}else if(p.gear<0&&vf<2)a=-p.thr*5*(ratio<1?1:0);
 vf+=a*dt;p.v.set(f.x*vf+l.x*vl,f.y*vf+l.y*vl);
 let spd=p.v.length();const dec=.0005*spd*spd+.3+(p.thr<.05?1.5*Math.min(ratio,1)+.2:0)+p.brk*32*wet+(p.hb?4:0);spd=Math.max(0,spd-dec*dt);p.v.setLength(spd);
 const np=p.p.clone().addScaledVector(p.v,dt),fx=f.x*2,fz=f.y*2;
 if(solid(np.x+fx,np.y+fz)||solid(np.x-fx,np.y-fz)||solid(np.x,np.y)){if(spd>4)hit();p.v.multiplyScalar(-.3)}else{p.dist+=spd*dt;p.p.copy(np)}
 p.p.x=cl(p.p.x,-320,320);p.p.y=cl(p.p.y,-320,320);
 for(const c of AI){if(!c.g.visible)continue;const dx=P.p.x-c.p.x,dz=P.p.y-c.p.y,d=Math.hypot(dx,dz);if(d<2.7){const nx=dx/(d||1),nz=dz/(d||1);P.p.x+=nx*(2.7-d);P.p.y+=nz*(2.7-d);if(P.v.length()>2||c.v>2){P.v.multiplyScalar(.6);c.v*=.3;c.ghost=2;hit()}}}
 for(const q of PED)if(q.down<=0&&spd>2&&Math.hypot(q.g.position.x-P.p.x,q.g.position.z-P.p.y)<1.4){q.down=4;say('Pedestrian hit!',1200);if(G.mode==='traffic')G.sc=Math.max(0,G.sc-300)}
 const slip=Math.atan2(Math.abs(vl),Math.max(Math.abs(vf),1))*57.3;D.ang=slip;
 if(sp>6&&slip>14&&slip<115){D.gap=0;D.act=1;D.chain+=dt;D.mult=Math.min(8,1+D.chain/2);D.cur+=dt*sp*slip*.25*D.mult}else if(D.act){D.gap+=dt;if(D.gap>.8)bank(0)}
 p.fuel=Math.max(0,p.fuel-dt*(.0004+p.thr*.0035*(sp/30+.3)));if(p.fuel<.12&&!p.low){p.low=1;say('LOW FUEL – find a gas station',2200)}if(p.fuel>.2)p.low=0;
 for(const s of GAS)if(Math.abs(P.p.x-s.x)<14&&Math.abs(P.p.y-s.z)<14&&spd<4&&p.fuel<1){p.fuel=Math.min(1,p.fuel+dt*.18);if(!p.rf){p.rf=1;say('Refuelling…',1200)}}else p.rf=0;
 // marks & smoke
 const slide=(Math.abs(vl)>3.2&&sp>4)||(p.hb&&spd>4)||(p.thr>.9&&sp<9&&p.gear===1&&Math.abs(p.steer)>.3);
 if(slide){const rl=P.p.clone().addScaledVector(f,-1.35);G.mk=(G.mk||0)+spd*dt;if(G.mk>.7){G.mk=0;[-.9,.9].forEach(s=>{const q=rl.clone().addScaledVector(l,s);put(MK,mi%900,q.x,.07,q.y,p.h);mi++;MK.count=Math.min(mi,900)});MK.instanceMatrix.needsUpdate=true}
  G.sm=(G.sm||0)-dt;if(G.sm<=0){G.sm=.04;[-.9,.9].forEach(s=>{const q=rl.clone().addScaledVector(l,s);puff(q.x,q.y,rnd(-.6,.6)+p.v.x*.15,rnd(-.6,.6)+p.v.y*.15)})}}
 // visuals
 const c=p.car,u=c.userData;c.position.set(p.p.x,0,p.p.y);c.rotation.y=p.h;u.b.rotation.z+=(cl(yaw*sp*.003,-.06,.06)-u.b.rotation.z)*.15;u.b.rotation.x+=(-cl((a-p.brk*20)*.0025,-.05,.05)-u.b.rotation.x)*.15;
 u.wh.forEach(w=>w.rotation.x+=vf*dt/.34);u.fr.forEach(w=>w.rotation.y=p.steer*.5);u.sw.rotation.z=-wa*PI/180;
 u.dr.forEach(d=>d.rotation.y+=(-d.userData.s*(p.door?1:0)-d.rotation.y)*cl(dt*6,0,1));
 const bl=Math.floor(G.clock*3)%2===0;if(bl!==G.lb){G.lb=bl;if(bl&&(P.ind||P.haz))AUDIO.play('indicator')}u.il.emissiveIntensity=(P.ind===1||P.haz)&&bl?3:0;u.ir.emissiveIntensity=(P.ind===-1||P.haz)&&bl?3:0;
 u.tm.emissiveIntensity=p.brk>.15||p.hb?3:p.hl?.7:.15;u.rm.emissiveIntensity=p.gear<0?2:0;u.hm.emissiveIntensity=p.hl?2:0;u.sp.forEach(s=>s.intensity=p.hl?2.4:0);
 $('il').style.opacity=(P.ind===1||P.haz)&&bl?1:.2;$('ir').style.opacity=(P.ind===-1||P.haz)&&bl?1:.2;
 acc=a;vlS=vl;P.spd=spd;P.vf=vf;
 AUDIO.update({rpm:p.rpm,thr:p.thr,sp:sp,brk:p.brk,slip:slide?cl(Math.abs(vl)/10,.2,1):0,eng:S.eng,sfx:S.sfx,mus:S.mus,wet:G.wx===1});}
// ---------- camera, sky
function updCam(dt){const p3=new V3(P.p.x,0,P.p.y),sp=P.spd||0;cam.fov+=((P.cam===1?78:62+sp*.35)-cam.fov)*.1;cam.updateProjectionMatrix();
 if(P.cam===0){const tp=new V3(P.p.x-Math.sin(P.h)*(7+sp*.03),2.8,P.p.y-Math.cos(P.h)*(7+sp*.03));cam.position.lerp(tp,1-Math.exp(-8*dt));cam.lookAt(p3.x+Math.sin(P.h)*3,1.3,p3.z+Math.cos(P.h)*3)}
 else if(P.cam===1){P.car.updateMatrixWorld(true);cam.position.copy(P.car.localToWorld(new V3(...(P.def.cp||[.4,1.15,.1]))));cam.rotation.set(0,P.h+PI,0)}
 else if(P.cam===3||P.cam===4){P.car.updateMatrixWorld(true);const Lh=P.car.userData.L/2;cam.position.copy(P.car.localToWorld(P.cam===3?new V3(0,.45,Lh+.1):new V3(0,1.1,Lh*.35)));cam.rotation.set(0,P.h+PI,0)}else if(P.cam===5){const y=P.h+G.clock*.35+PI;cam.position.set(p3.x+Math.sin(y)*7,1.2+Math.sin(G.clock*.5)*.6,p3.z+Math.cos(y)*7);cam.lookAt(p3.x,.8,p3.z)}else{const y=P.h+P.fy+PI;cam.position.set(p3.x+Math.sin(y)*9*Math.cos(P.fp),Math.sin(P.fp)*9+.5,p3.z+Math.cos(y)*9*Math.cos(P.fp));cam.lookAt(p3.x,1.2,p3.z)}}
const NC=new THREE.Color(0x070b18),DC=new THREE.Color(0x8cc4ff),OC=new THREE.Color(0xff8a50),GC=new THREE.Color(0x8b929c);
function sky(dt){G.tod=(G.tod+dt/50)%24;const e=Math.sin((G.tod-6)/12*PI),k=cl(e*1.8+.25,0,1),dk=cl(1-Math.abs(e)*4,0,1),nf=1-k,wx=G.wx;
 const c=NC.clone().lerp(DC,k).lerp(OC,dk*.45);if(wx)c.lerp(GC.clone().multiplyScalar(.25+.75*k),wx===1?.6:.85);sc.background.copy(c);sc.fog.color.copy(c);sc.fog.density=[.0016,.005,.014][wx];
 const sx=Math.cos((G.tod-6)/12*PI)*100,sy=Math.max(20,e*110+20);sun.position.set(P.p.x+sx,sy,P.p.y+40);sun.target.position.set(P.p.x,0,P.p.y);sun.color.setHex(dk>.3?0xffb070:0xffffff);sun.intensity=.1+k*(wx===1?.6:1.05);hemi.intensity=.18+.62*k;
 NB.forEach(m=>m.emissiveIntensity=nf*.9);bulbM.color.setScalar(.25+nf*.75).multiply(new THREE.Color(1,.9,.65));hdA.color.setHex(nf>.4?0xffffcc:0x555544);tlA.color.setHex(nf>.4?0xaa0000:0x440000);
 roadM.roughness=plainM.roughness=wx===1?.3:.9;rn.visible=wx===1;if(wx===1){const a=rp;for(let i=0;i<900;i++){const j=i*6;a[j+1]-=35*dt;a[j+4]-=35*dt;if(a[j+4]<0){a[j+1]+=25;a[j+4]+=25}}rn.geometry.attributes.position.needsUpdate=true;rn.position.set(cam.position.x,cam.position.y-8,cam.position.z)}
 [0,1].forEach(a=>{const s=ls(a);LM[a].r.color.setHex(s==='r'?0xff2222:0x2a0505);LM[a].y.color.setHex(s==='y'?0xffc400:0x2a2200);LM[a].g.color.setHex(s==='g'?0x22ff66:0x052a10)})}
// ---------- game modes
const MODES=['free','drift','traffic','park','trial','school'],CP=[[0,150],[150,150],[150,-100],[-100,-100],[-100,100],[0,0]];
const mk=new THREE.Group(),beam=new THREE.Mesh(new THREE.CylinderGeometry(1,1,60,24,1,true),new THREE.MeshBasicMaterial({color:0x18e0d0,transparent:true,opacity:.3,side:THREE.DoubleSide,depthWrite:false})),pk=new THREE.Mesh(new THREE.PlaneGeometry(3.4,6.4).rotateX(-PI/2),new THREE.MeshBasicMaterial({color:0x18e0d0,transparent:true,opacity:.55}));
beam.position.y=30;pk.position.y=.4;mk.add(beam,pk);mk.visible=false;sc.add(mk);
const SCH=[['Accelerate to 50 km/h',()=>P.spd*3.6>=50],['Brake to a full stop',()=>P.spd<.4],['Turn on the LEFT indicator',()=>P.ind===1],['Turn on the headlights',()=>P.hl],['Shift to R and reverse 10 m',()=>G.rev>=10],['Press D, then drift (handbrake + steer)',()=>P.gear>0&&D.act&&D.ang>20]];
function resetCar(){Object.assign(P,{p:new V2(-3.5,-40),h:0,gear:1,man:0,rpm:900,fuel:1,thr:0,brk:0,steer:0,ind:0,haz:0,hl:0,door:0,sc:0});P.v.set(0,0);wa=0;bank(1);D.total=0}
function begin(m){G.mode=m;G.on=1;G.paused=0;G.sc=0;G.clean=0;G.rev=0;$('menu').hidden=true;$('hud').hidden=false;resetCar();toggles();const n=m==='traffic'?12:6;AI.forEach((c,i)=>{c.g.visible=i<n;placeAI(c)});mk.visible=false;
 if(m==='drift')G.t=90;if(m==='traffic')G.t=120;if(m==='park'){G.n=0;G.t=70;setPark()}if(m==='trial'){G.cp=0;G.t=0;setCP()}if(m==='school'){G.st=0}
 say(T(m),1800);cam.position.set(P.p.x,3,P.p.y-8)}
function setPark(){const l=LOTS[(G.n*2+1)%LOTS.length];G.tg=l;pk.visible=true;beam.scale.set(3,1,3);mk.position.set(l.x,0,l.z);mk.visible=true;G.hold=0}
function setCP(){const c=CP[G.cp];pk.visible=false;beam.scale.set(7,1,7);mk.position.set(c[0],0,c[1]);mk.visible=true}
function endGame(txt,key,val,low){G.on=0;mk.visible=false;const b=S.best[key];let nb='';if(val!=null&&(b==null||(low?val<b:val>b))){S.best[key]=val;save();nb='<br>★ New best'}modal(txt+nb,[[T('retry'),()=>begin(G.mode)],[T('menu'),toMenu]])}
function modeStep(dt){const m=G.mode;if(!G.on)return;
 if(m==='drift'){G.t-=dt;if(G.t<=0){bank(0);const pl=1+[3000,6000,10000].filter(r=>D.total<r).length;endGame(`Competition over<br>Score ${D.total} · Place #${pl}/4`,'drift',D.total)}}
 else if(m==='traffic'){G.t-=dt;G.clean+=dt;const kmh=P.spd*3.6;G.sc+=dt*cl(kmh-50,0,200)*.05*(1+Math.floor(G.clean/8));if(G.t<=0)endGame('Traffic run over<br>Score '+Math.round(G.sc),'traffic',Math.round(G.sc))}
 else if(m==='park'){G.t-=dt;const l=G.tg,dx=P.p.x-l.x,dz=P.p.y-l.z,ah=Math.abs(((P.h*57.3)%180+180)%180),ok=Math.abs(dx)<1.7&&Math.abs(dz)<3.4&&(ah<18||ah>162)&&P.spd<.6;G.hold=ok?G.hold+dt:0;
  if(G.hold>1.2){G.n++;if(G.n>=3)endGame('Parked 3/3<br>Time left '+Math.round(G.t)+'s','park',Math.round(G.t));else{G.t+=40;say('Parked! Next spot',1500);setPark()}}else if(G.t<=0)endGame('Time up','');}
 else if(m==='trial'){G.t+=dt;const c=CP[G.cp];if(Math.hypot(P.p.x-c[0],P.p.y-c[1])<10){G.cp++;if(G.cp>=CP.length)endGame('Finished '+G.t.toFixed(1)+' s','trial',+G.t.toFixed(1),1);else{say('Checkpoint '+G.cp+'/'+CP.length,1000);setCP()}}}
 else if(m==='school'){if(P.gear<0)G.rev+=-P.vf*dt;if(SCH[G.st][1]()){G.st++;if(G.st>=SCH.length){endGame('Licence passed!<br>All lessons complete','school',1)}else say('✓ Well done',900)}}
 const hs=$('mi');hs.textContent=m==='drift'?`⏱ ${Math.max(0,G.t|0)}s   SCORE ${D.total}`:m==='traffic'?`⏱ ${Math.max(0,G.t|0)}s   PTS ${Math.round(G.sc)}  x${1+Math.floor(G.clean/8)}`:m==='park'?`Spot ${G.n+1}/3  ⏱ ${Math.max(0,G.t|0)}s${G.hold>0?'  HOLD…':''}`:m==='trial'?`CP ${G.cp}/${CP.length}   ${G.t.toFixed(1)}s`:m==='school'&&G.on?`${G.st+1}/${SCH.length}  ${SCH[G.st][0]}`:''}
// ---------- UI
function modal(h,btns){const e=$('md');e.innerHTML=`<h2 style="text-align:center">${h}</h2>`;btns.forEach(([t,f])=>{const b=document.createElement('button');b.className='mb';b.textContent=t;b.onclick=()=>{e.hidden=true;f()};e.append(b)});e.hidden=false}
function pauseMenu(){G.paused=1;modal(T('paused'),[[T('resume'),()=>G.paused=0],[T('settings'),()=>openSet(pauseMenu)],[T('menu'),toMenu]])}
function toMenu(){G.on=0;G.paused=1;mk.visible=false;$('hud').hidden=true;$('menu').hidden=false;drawMenu()}
let setBack;function openSet(back){setBack=back;$('st').hidden=false;drawSet()}$('sbk').onclick=()=>{$('st').hidden=true;setBack&&setBack()};
function fs(){try{const d=document.documentElement;if(document.fullscreenElement)document.exitFullscreen();else{(d.requestFullscreen||d.webkitRequestFullscreen).call(d);screen.orientation&&screen.orientation.lock&&screen.orientation.lock('landscape').catch(()=>{})}}catch(e){}}
const ROWS=[['gfx','sel',['low','med','high']],['res','sel',['50%','75%','100%']],['sfx','rng',0,1],['eng','rng',0,1],['mus','rng',0,1],['steer','rng',.5,2],['ws','rng',.7,1.4],['cs','rng',.3,3],['tilt','sel',['Off','On','Inverted']],['arr','tog'],['swap','tog'],['lang','sel',['English','Español']],['wx','sel',['Clear','Rain','Fog']],['tod','rng',0,24],['full','btn']];
function drawSet(){$('sh').textContent=T('settings');$('sbk').textContent=T('back');const el=$('srows');el.innerHTML='';ROWS.forEach(([k,t,a,b])=>{const r=document.createElement('div');r.className='row';const lb=document.createElement('span');lb.textContent=T(k);r.append(lb);const O=k==='wx'||k==='tod'?G:S;
 if(t==='rng'){const i=document.createElement('input');i.type='range';i.min=a;i.max=b;i.step=k==='tod'?.25:.05;i.value=O[k];i.oninput=()=>{O[k]=+i.value;save();applyAll()};r.append(i)}
 else{const bt=document.createElement('button');bt.className='sb';const L=()=>t==='tog'?(S[k]?'ON':'OFF'):t==='btn'?'⛶':k==='gfx'?T(a[S[k]]):a[O[k]];bt.textContent=L();bt.onclick=()=>{if(t==='tog')S[k]^=1;else if(t==='btn')fs();else{O[k]=(O[k]+1)%a.length;if(k==='tilt'&&O[k]&&window.DeviceOrientationEvent&&DeviceOrientationEvent.requestPermission)DeviceOrientationEvent.requestPermission().catch(()=>{})}save();applyAll();drawSet()};r.append(bt)}el.append(r)})}
function applyAll(){applyGfx();document.documentElement.style.setProperty('--ws',S.ws);$('ctl').className=S.swap?'sw':'';$('wheel').style.display=S.arr?'none':'';$('ar').hidden=!S.arr}
function drawMenu(){const c=$('cars');c.innerHTML='';CARS.forEach((d,i)=>{const b=document.createElement('button');b.className='mb'+(S.car===i?' s':'');b.textContent=d.n+(ASSETS.ok[i]?'':' ✕');b.disabled=!ASSETS.ok[i];b.onclick=()=>{setCar(i);drawMenu()};c.append(b)});
 const m=$('modes');m.innerHTML='';MODES.forEach(k=>{const b=document.createElement('button');b.className='mb';b.textContent=T(k);b.onclick=()=>{initAudio();begin(k)};m.append(b)});
 $('mset').textContent=T('settings');$('mfs').textContent=T('full');$('mset').onclick=()=>openSet(()=>drawMenu());$('mfs').onclick=fs;const bs=S.best;$('best').textContent=`${T('best')}: drift ${bs.drift||0} · traffic ${bs.traffic||0} · trial ${bs.trial?bs.trial+'s':'–'}`;if(ASSETS.missing.length)$('best').textContent+=' | Missing assets: '+ASSETS.missing.join(', ')}
// ---------- main loop
let last=performance.now(),fr=0;
function loop(now){requestAnimationFrame(loop);const dt=Math.min(.05,(now-last)/1000);last=now;fr++;
 if(!G.paused){G.clock+=dt;G.lt=(G.lt+dt)%CYC;if(G.cd>0)G.cd-=dt;drive(dt);AI.forEach(c=>c.g.visible&&updAI(c,dt));PED.forEach(p=>updPed(p,dt));modeStep(dt);
  SM.forEach(s=>{const d=s.userData;if(d.l>0){d.l-=dt;s.scale.setScalar(1.2+(1-d.l/d.m)*4.5);s.material.opacity=.5*Math.max(0,d.l/d.m);s.position.x+=d.vx*dt;s.position.z+=d.vz*dt;s.position.y+=1.1*dt;if(d.l<=0)s.visible=false}});
  const kmh=P.spd*3.6;$('spd').textContent=Math.round(kmh);$('rf').style.width=cl((P.rpm-900)/6700*100,0,100)+'%';$('gr').textContent=P.gear<0?'R':P.gear===0?'N':P.gear;$('fu').firstChild.style.width=P.fuel*100+'%';
  $('ds').textContent=D.act?`DRIFT ${Math.round(D.cur)}  x${D.mult.toFixed(1)}`:`DRIFT TOTAL ${D.total}`;$('wheel').firstElementChild.style.transform=`rotate(${wa}deg)`;
  sky(dt);updCam(dt)}
 else{sky(0)}
 const iv=S.gfx>1?20:S.gfx>0?120:100000;if(!G.envDone||fr%iv===1){G.envDone=1;P.car.visible=false;cubeCam.position.set(P.p.x,1.4,P.p.y);cubeCam.update(R,sc);P.car.visible=true}
 R.render(sc,cam)}
setCar(ASSETS.ok[S.car]?S.car:ASSETS.ok.indexOf(true));applyAll();cam.aspect=innerWidth/innerHeight;cam.position.set(-12,4,-60);cam.lookAt(0,1,-30);AI.forEach(c=>{c.g.visible=true;placeAI(c)});
$('menu').hidden=false;drawMenu();requestAnimationFrame(loop);

})();
